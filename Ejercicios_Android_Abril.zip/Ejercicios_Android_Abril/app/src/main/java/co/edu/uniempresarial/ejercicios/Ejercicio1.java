package co.edu.uniempresarial.ejercicios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Ejercicio1 extends AppCompatActivity {

    EditText etFecha;
    Button btnCalcular;
    Button btnMenu;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio1);

        etFecha     = findViewById(R.id.etFecha);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnMenu     = findViewById(R.id.btnMenu);
        tvResult    = findViewById(R.id.tvResult);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularFecha();
            }
        });

        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }


    private void calcularFecha(){
        String strFecha = etFecha.getText().toString();
        SimpleDateFormat formatoFec = new SimpleDateFormat("dd/mm/yyyy");

        try {
            Date fechaNacimiento = formatoFec.parse(strFecha);
            Date fechaActual = new Date();
            long convertD = TimeUnit.DAYS.toMillis(365);
            long lapso = fechaActual.getTime() - fechaNacimiento.getTime();
            long edad = lapso / convertD;
            tvResult.setText("Edad: " + edad + " años");
        } catch (ParseException e) {
            tvResult.setText("Formato de fecha incorrecto");
        }
    }
}