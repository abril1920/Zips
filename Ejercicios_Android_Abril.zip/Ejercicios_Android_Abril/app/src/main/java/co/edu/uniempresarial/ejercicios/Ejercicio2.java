package co.edu.uniempresarial.ejercicios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Ejercicio2 extends AppCompatActivity {
    private EditText etName;
    private EditText etLastname;
    private EditText etDireccion;
    private Button btnComprar;



    private void start() {
        etName      = findViewById(R.id.etName);
        etLastname  = findViewById(R.id.etLLastname);
        etDireccion = findViewById(R.id.etDireccion);
        btnComprar  = findViewById(R.id.btnComprar);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio2);

        start();
        btnComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data(view);
            }
        });
    }
    private void data(View view) {
        String nombres  = etName.getText().toString().trim();
        String apellidos= etLastname.getText().toString().trim();
        String direccion= etDireccion.getText().toString().trim();

        if (nombres.isEmpty() || apellidos.isEmpty() || direccion.isEmpty()) {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
        } else {
            comprar(nombres, apellidos, direccion);
        }
    }

    private void comprar (String names, String lastname, String direccion){
        Intent intent = new Intent(getApplicationContext(), Ejercicio2_1.class);
        intent.putExtra("Nombres", names);
        intent.putExtra("Apellidos", lastname);
        intent.putExtra("Direccion", direccion);
        startActivity(intent);
    }



}