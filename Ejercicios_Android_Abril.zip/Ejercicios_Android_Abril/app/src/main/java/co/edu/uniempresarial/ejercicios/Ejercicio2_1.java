package co.edu.uniempresarial.ejercicios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class Ejercicio2_1 extends AppCompatActivity {

    private CheckBox cbalpinito;
    private CheckBox cbtampico;
    private CheckBox cbchocorramo;
    private CheckBox cbtrululu;
    private CheckBox cbsplot;
    private CheckBox cbSuperricas;
    private Button btnFactura;

    private String nombres;
    private String apellidos;
    private String direccion;



    private void Iniciar() {
        cbalpinito      = findViewById(R.id.cbAlpinito);
        cbchocorramo    = findViewById(R.id.cbChocorramo);
        cbsplot         = findViewById(R.id.cbSplot);
        cbtampico       = findViewById(R.id.cbTampico);
        cbtrululu       = findViewById(R.id.cbTrululu);
        cbSuperricas    = findViewById(R.id.cbSuperricas);
        btnFactura      = findViewById(R.id.btnComprar);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio21);


        nombres = getIntent().getStringExtra("Nombres");
        apellidos = getIntent().getStringExtra("Apellidos");
        direccion = getIntent().getStringExtra("Direccion");


        Iniciar();

        btnFactura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String seleccionProd = TraerProductos();

                Intent intent = new Intent(Ejercicio2_1.this, Facutra.class);
                intent.putExtra("Nombres", nombres);
                intent.putExtra("Apellidos", apellidos);
                intent.putExtra("Direccion", direccion);
                intent.putExtra("ProductosSeleccionados", seleccionProd);
                startActivity(intent);

            }
        });
    }



    private String TraerProductos() {
        StringBuilder Seleccionar = new StringBuilder();

        if (cbalpinito.isChecked()) {
            Seleccionar.append("Alpinito, ");
        }
        if (cbchocorramo.isChecked()) {
            Seleccionar.append("Chocorramo, ");
        }
        if (cbtampico.isChecked()) {
            Seleccionar.append("Tampico, ");
        }
        if (cbsplot.isChecked()) {
            Seleccionar.append("Splots, ");
        }
        if (cbtrululu.isChecked()) {
            Seleccionar.append("Gomas trululu, ");
        }
        if (cbSuperricas.isChecked()) {
            Seleccionar.append("Superricas, ");
        }


        if (Seleccionar.length() > 0) {
            Seleccionar.setLength(Seleccionar.length() - 2);
        }

        return Seleccionar.toString();
    }
}