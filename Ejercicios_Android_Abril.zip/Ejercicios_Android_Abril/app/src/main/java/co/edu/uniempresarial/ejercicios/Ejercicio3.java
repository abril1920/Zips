package co.edu.uniempresarial.ejercicios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Ejercicio3 extends AppCompatActivity {

    private RadioGroup rgRespuestasMultiples;
    private TextView tvEnunPreg;
    private Button btnSeguir;
    private Button btnMenu3;
    private int preguntaActual = 0;
    private int score = 0;

    private Preguntas[] preguntasMul;

    public class Preguntas {
        private String pregunta;
        private String[] opciones;
        private int opcionCorrecta;

        public Preguntas(String enunciadoPreg, String[] opciones, int opcionCorrecta){
            this.pregunta = enunciadoPreg;
            this.opciones = opciones;
            this.opcionCorrecta = opcionCorrecta;
        }

        public String getPregunta() {

            return pregunta;
        }

        public String[] getOpciones() {

            return opciones;
        }

        public int getOpcionCorrecta() {

            return opcionCorrecta;
        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio3);

        tvEnunPreg     = findViewById(R.id.tvEnunPreg);
        rgRespuestasMultiples= findViewById(R.id.rgRespuestasMultiples);// opciones multiples
        btnSeguir   = findViewById(R.id.btnSeguir);
        btnMenu3    = findViewById(R.id.btnMenu3_0);

        preguntasMul = new Preguntas[]{
                new Preguntas("¿Cuando inicio la primera Guerra Mundíal?",
                        new String[]{"1920","1918","1914","1939"},2),
                new Preguntas("¿Cuando termino la primera Guerra Mundíal?",
                        new String[]{"1920","1918","1914","1939"},1),
                new Preguntas("¿En que año se produjo la revolución francesa?",
                        new String[]{"1789","1600","1714","1900"},0),
                new Preguntas("¿Cuál es el océano más grande del mundo?",
                        new String[]{"Océano pacifico","Océano Atlántico","Océano Ártico","Océano indico"},0),
                new Preguntas("¿Cómo se llama el proceso por el cual las plantas se alimentan?",
                        new String[]{"El masatero","Rejuvenecer","Darle tiempo al tiempo","fotosíntesis"},3),
                new Preguntas("¿Cómo se llama el triángulo que tiene sus tres lados iguales?",
                        new String[]{"Equilátero","TrianguloX3","isósceles","rectángulo"},2),
        };

        cargarpregunta(preguntaActual);

        btnSeguir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int idResSeleccionado = rgRespuestasMultiples.getCheckedRadioButtonId();
                if (idResSeleccionado != -1){
                    RadioButton rbSeleccionada = findViewById(idResSeleccionado);
                    String opcionSeleccionado = rbSeleccionada.getText().toString();
                    Preguntas preguntas = preguntasMul[preguntaActual];
                    int indiceOpcionCorrecta = preguntas.getOpcionCorrecta();
                    String opcionCorrecta = preguntas.getOpciones()[indiceOpcionCorrecta];

                    if (opcionSeleccionado.equals(opcionCorrecta)){
                        score++;
                    }
                    preguntaActual++;
                    if (preguntaActual < preguntasMul.length){
                        cargarpregunta(preguntaActual);
                    } else {
                        RespuestasCorrectas();
                    }
                }
            }
        });


        btnMenu3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
    private void cargarpregunta(int NumeroPr){
        Preguntas pregunta = preguntasMul[NumeroPr];
        tvEnunPreg.setText(pregunta.getPregunta());
        rgRespuestasMultiples.removeAllViews();

        for (String opcion : pregunta.getOpciones()) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(opcion);
            rgRespuestasMultiples.addView(radioButton);
        }
    }


    private void RespuestasCorrectas(){
        btnSeguir.setEnabled(false);
        TextView tvPuntaje = findViewById(R.id.tvResult);
        String message = "Respuestas correctas: "+ score +"/"+ preguntasMul.length;
        tvPuntaje.setText(message);
    }

}