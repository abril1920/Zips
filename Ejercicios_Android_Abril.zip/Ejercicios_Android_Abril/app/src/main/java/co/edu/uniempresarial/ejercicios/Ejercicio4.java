package co.edu.uniempresarial.ejercicios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class Ejercicio4 extends AppCompatActivity {
    private EditText etAltura;
    private EditText etPeso;
    private Button btnCalcular4;
    private Button btnMenu4;
    private TextView tvResult4;
    private RadioButton rbMetrico;
    private RadioButton rbIngles;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio4);

        etAltura    = findViewById(R.id.etAltura);
        etPeso      =findViewById(R.id.etPeso);
        rbIngles    =findViewById(R.id.rbIngles);
        rbMetrico   =findViewById(R.id.rbMetrico);
        btnCalcular4=findViewById(R.id.btnCalcular4);
        btnMenu4    =findViewById(R.id.btnMenu4);
        tvResult4   =findViewById(R.id.tvResult4);


        btnCalcular4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularMC();
            }
        });



        btnMenu4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void calcularMC(){
        float altura, peso;
        try{
            altura  = Float.parseFloat(etAltura.getText().toString());
            peso    = Float.parseFloat(etPeso.getText().toString());
        } catch (NumberFormatException e){
            tvResult4.setText("Ingrese Valores solicitados.");
            return;
        }

        float mc = 0;
        if(rbIngles.isChecked()){
            peso    = peso * 0.45f;
            altura  = altura* 0.025f;
            mc      = peso / (altura * altura);
        } else if (rbMetrico.isChecked()) {
            mc = peso / (altura*2);
        }
        verResultado (mc);
    }

    private void verResultado(float mc) {
        String clasificacion = null;

        if (mc <18.5){
            clasificacion = ("Bajo peso");
        } else if (mc >= 18.5 && mc < 25) {
            clasificacion = ("Normal");
        } else if (mc >25.0 && mc < 29.9) {
            clasificacion = ("El peso es mas alto de lo normal");
        } else if (mc > 30.0) {
            clasificacion = ("Obesidad");
        }

        tvResult4.setText("mc: "+ mc +"\n" +"Clasdificación: "+ clasificacion);
    }
}