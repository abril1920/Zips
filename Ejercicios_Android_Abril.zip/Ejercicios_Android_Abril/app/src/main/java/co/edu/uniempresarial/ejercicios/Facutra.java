package co.edu.uniempresarial.ejercicios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Facutra extends AppCompatActivity {
    private TextView tvDetalles;
    private Button btnMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facutra);

        tvDetalles  = findViewById(R.id.tvDetalles);
        btnMenu     = findViewById(R.id.btnMenu2);

        Intent intent   = getIntent();
        String nombre   = intent.getStringExtra("Nombres");
        String apellido = intent.getStringExtra("Apellidos");
        String direccion= intent.getStringExtra("Direccion");
        String seleccionProd = intent.getStringExtra("ProductosSeleccionados");

        String factura = "Cliente: "+ nombre +" "+ apellido +"\n";
        factura += "Dirección: "+ direccion +"\n";
        factura += "Productos Seleccionados: "+ seleccionProd;

        tvDetalles.setText(factura);


        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}